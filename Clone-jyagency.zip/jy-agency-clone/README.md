# J & Y Agency Website Clone

This is a static HTML/CSS clone of the J&Y Agency website, optimized for GitHub Pages deployment.

## Connecting Your Domain to GitHub Pages

Follow these steps to host this website on GitHub Pages and connect your custom domain:

### 1. Create a GitHub Repository

1. Sign in to your GitHub account
2. Click the "+" icon in the top right and select "New repository"
3. Name your repository (e.g., `jyagency` or any name you prefer)
4. Set the repository to "Public"
5. Click "Create repository"

### 2. Upload the Files

#### Option 1: Upload via GitHub UI
1. Navigate to your new repository
2. Click the "Add file" dropdown and choose "Upload files"
3. Drag and drop or select all files from the `dist` folder
4. Commit the changes directly to the main branch

#### Option 2: Use Git Command Line
```bash
# Navigate to the dist directory
cd jy-agency-clone/dist

# Initialize a Git repository
git init

# Add all files
git add .

# Commit the files
git commit -m "Initial commit"

# Add your remote repository URL
git remote add origin https://github.com/yourusername/your-repository-name.git

# Push to GitHub
git push -u origin main
```

### 3. Configure GitHub Pages

1. Go to your repository on GitHub
2. Click "Settings" in the top menu
3. Scroll down to the "GitHub Pages" section (or click "Pages" in the left sidebar)
4. Under "Source", select "main" branch
5. Click "Save"

### 4. Connect Your Custom Domain

1. In the same GitHub Pages section, find the "Custom domain" field
2. Enter your domain name (e.g., `jyagency.com`)
3. Click "Save"
4. GitHub will create a CNAME file in your repository

### 5. Configure Your Domain DNS Settings

Go to your domain registrar's website and update your DNS settings:

#### For an apex domain (example.com):
Add these A records:
```
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
```

#### For a subdomain (www.example.com):
Add a CNAME record:
- Name: www (or your subdomain)
- Value: yourusername.github.io

### 6. Verify Your Domain

1. Return to GitHub Pages settings
2. You'll see a message about DNS verification
3. Wait for GitHub to verify your domain (may take up to 24 hours)
4. Once verified, check "Enforce HTTPS" for secure connections

Your website should now be live at your custom domain!

## Making Updates

To make changes to the website:
1. Edit the files in your repository
2. Commit and push the changes
3. GitHub Pages will automatically rebuild and deploy your site

## About This Clone

This is a static HTML/CSS clone of the J&Y Agency website, featuring:
- Home page
- XHS services page
- Contact page
- Responsive design
- Exact replica of original styling and content
